This dataset was split into multiple ZIP files so each archive stays under 25 MB.

Contents:
- gtfs_small_files.zip: all original smaller GTFS files unchanged
- stop_times_part1.zip + stop_times_part2.zip: split versions of stop_times.txt
- shapes_part1.zip + shapes_part2.zip: split versions of shapes.txt

Important:
- stop_times.txt and shapes.txt are split across two files each.
- Each part repeats the original header row.
- To rebuild the original files exactly, keep only the header from part1 and append the data rows from part2 without its header.

Suggested reconstruction:
1) Unzip all archives into one folder.
2) For stop_times:
   - keep stop_times_part1.txt as base
   - append stop_times_part2.txt starting from line 2
3) For shapes:
   - keep shapes_part1.txt as base
   - append shapes_part2.txt starting from line 2

Original source archive: 2025-04-04.gtfs.zip
